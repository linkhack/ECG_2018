Author:
11728332 Patrick Link

Tested on NVIDIA hardware.