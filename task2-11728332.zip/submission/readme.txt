Author:
11728332 Patrick Link

Bonus Task: Strafing
    - right and zAxis are the axes corresponding to up direction and right direction in camera
      coordinate system. We can add the difference of x and y of mouse in these directions to strafe and 
      add strafe to the position of the camera.
    - the roation part is the same without strafe or with strafe. Looking at 0 from position is the 
      same as looking at strafe from strafe + position
  

Tested on NVIDIA hardware.